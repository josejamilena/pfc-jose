/*
 * datagen.c	: generate dataset for benchw suite
 * 
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 * Bugs 		: should really check return code from all malloc's
 */


/*
 * required includes
 */
#include "inc.h"


/*
 * relation structures
 */
#include "rel.h"


/*
 * defines and constants for data creation 
 */
#include "dat.h"


/*
 * write a formatted attribute to the temporary buffer 
 */
void	fmt_attr(char *tempbuf, int len, int islast, int fmt){

	int	tlen = 0;
	int	i;
	/*
	 * if delimited case, then append a "," if not processing
	 * the last attribute
	 * otherwise (fixed width) pad the value out to the max length
	 */
	if (fmt == DEL) {
		if (islast != 1) {
			strcat(tempbuf, ",");
		} 
	} else {
		tlen = strlen(tempbuf);
		if (tlen < len) {
			for (i = tlen ; i < len; i++) { 
				tempbuf[i] = ' ';
			}
			tempbuf[len] = '\0';
		}
	} 
	return;
}


/*
 * write the dimension files
 *
 */
int	write_dim(Rel *rels, int relno, float size, char *path, int fmt) {

	int		line;
	int		i;
	char	*dimfile;
	int		fd;
	char	*buffer;
	char	*tempbuf;
	char	*filbuf;

	int		year = SYEAR, mth = 1, day = 1, mday = 1;

	/*
	 * work out the file name
	 */
	dimfile = malloc(strlen(path) + strlen(rels[relno].name) + 6);
	sprintf(dimfile, "%s%s%s%s", path, "/", rels[relno].name, ".dat");

	/*
	 * open the file
	 */
	if ((fd = open(dimfile, OPENOPTS, OPENFLGS )) == -1 ) {
		perror("could not create");
		return 1;
	}

	/*
	 * allocate the maximum space that could be used by the relation's
	 * attributes
	 */
	buffer = malloc(getreltotalattrslen(rels, relno) + 2);
	tempbuf = malloc(getrelmaxattrslen(rels, relno) + 2);
	filbuf = malloc(getrelmaxattrslen(rels, relno) + 1);


	/*
	 * write the timelike dimension
	 */
	if ( strcmp(rels[relno].type, "timelike dimension") == 0 ) {

		printf("        :    %s\n", dimfile);

		for (line = 0 ; line < SCALE ; line++) {
			/*
			 * set up and write
			 *
			 * at this point the structure of the attributes is assumed
			 * it might be nice to make this smarter...
			 * but if the structure is altered in rel.c... what should
			 * we do here?
			 */

			buffer[0] = '\0';
			for (i = 0; i < rels[relno].noattrs ; i++) {
				switch (i) {
				case 0 :
					sprintf(tempbuf, "%d", line);
					break;
				case 1 :
					sprintf(tempbuf, "%d-%02d-%02d", year, mth, mday);
					break;
				case 2 :
					sprintf(tempbuf, "%d", year);
					break;
				case 3 :
					sprintf(tempbuf, "%d", mth);
					break;
				case 4 :
					sprintf(tempbuf, "%d", day);
					break;
				}
				if (i == rels[relno].noattrs - 1) {
					fmt_attr(tempbuf, rels[relno].attrs[i].len, 1, fmt);
				} else {
					fmt_attr(tempbuf, rels[relno].attrs[i].len, 0, fmt);
				}
				strcat(buffer, tempbuf);
			}

			strcat(buffer, "\n");
			if( write(fd, buffer, strlen(buffer)) == -1 ) {
				perror("failed to write");
				return 2 ;
			}

			/*
			 * increment things, and do basic date processing
			 */
			day++;
			mday++;

			if (day > 7 ) {
				day = 1;
			}

			if (mday > MDAY){
				mday = 1;
				mth++;
			}

			if (mth > 12) {
				mday = 1;
				mth = 1;
				year++;
			}

        }

	} else {

		printf("        :    %s\n", dimfile);

		for (line = 0 ; line < size * SCALE ; line++) {
			/*
			 * set up and write a non timelike dimension
			 *
			 * these are almost the same, except for the number of
			 * distinct types - which decreases  logarithmically 
			 * as the dimension number (i.e relno) increases 
			 */

			/* random text for a filler */
			for (i = 0; i < FILLEN; i++) {
				filbuf[i] = (char)(CHRST + random() % CHROFF);
			}
			filbuf[i] = '\0';
			
			strcpy(buffer, "");
			for (i = 0; i < rels[relno].noattrs ; i++) {
				switch (i) {
				case 0 :
					sprintf(tempbuf, "%d", line);
					break;
				case 1 :
					sprintf(tempbuf, "%d%s", line, DIMF1);
					break;
				case 2 :
					sprintf(tempbuf, "%d%s",  line%(int)(DIMTYP/(log10(relno + 1) + 1)), DIMF2);
					break;
				case 3 :
					sprintf(tempbuf, "%s", filbuf);
					break;
				}
				if (i == rels[relno].noattrs - 1) {
					fmt_attr(tempbuf, rels[relno].attrs[i].len, 1, fmt);
				} else {
					fmt_attr(tempbuf, rels[relno].attrs[i].len, 0, fmt);
				}
				strcat(buffer, tempbuf);
			}
			strcat(buffer, "\n");

			if( write(fd, buffer, strlen(buffer)) == -1 ) {
				perror("failed to write");
				return 2;
			}

		}

		free(filbuf);

	}

	free(tempbuf);
	free(buffer);
 
	close(fd);
	free(dimfile);	

	return 0;
}


/*
 * write the fact file
 */
int	write_fact(Rel *rels, int relno, float size, char *path, int fmt) {

	int		fd;
	char 	*factfile;
	char	*buffer;
	char	*tempbuf;
	char	*filbuf;

	int		*key;
	int		*keylim;
	int		k, j, i;

	int		line = 0;
	int		linelim = 1;
	int		val;
	int		nodims = NORELS - 1;

	factfile = malloc(strlen(path) + strlen(rels[relno].name) + 6);
	sprintf(factfile, "%s%s%s%s", path, "/", rels[relno].name, ".dat");

	/*
	 * open the file
	 */
	if ((fd = open(factfile, OPENOPTS, OPENFLGS)) == -1 ) {
		perror("could not create");
		return 1 ;
	}

	printf("        :    %s\n", factfile);

	/*
	 * start the fact file setup...
	 *
	 * an array of keys (one for each dimension) are used together with a
	 * limit for each one.
	 *
	 * allocate space for the key and keylimit arrays
	 * set the limits for each key range, initialize each key
	 * and work out the overall line limit from the dimension limits.
	 *
	 * note that the time dimension does *not* scale with increasing size,
	 * only the first non timelike dimension does
	 * this is done to keep the queries seeing a constant percentage of
	 * the fact table
	 *
	 */
	key = malloc(nodims * sizeof(int));
	keylim = malloc(nodims * sizeof(int));
	for (k = 0; k < nodims; k++) {
		if ( k == 0 ) {
			keylim[k] = SCALE;
		} else if (k == 1 ) {
			keylim[k] = (SCALE / 100) * size;
		} else {
			keylim[k] = (SCALE / 100)/ 10 ;
		}
		linelim = linelim * keylim[k];
		key[k] = 0;
	}

	/*
	 * initialize the buffer to write and also a temp buffer
	 *
	 * run through each dimension keyset and increment when the limit for
	 * each one is reached. there is a little subtlety when serveral limits
	 * are reached together
	 *
	 * in addition add a field to emulate a measured value of interest,
	 * plus another that is purely a filler to make the record length
	 * more challenging.
	 *
	 * then write the record
	 */
	buffer = malloc(getreltotalattrslen(rels, relno) + 1);
	tempbuf = malloc(getrelmaxattrslen(rels, relno) + 1);
	filbuf = malloc(getrelmaxattrslen(rels, relno) + 1);

	for (k = 0; k < nodims; k++) {
		while ( line < linelim) {
			for (j = 0; j < nodims; j++) {
				if ( key[j] == keylim[j]) {
					key[j] = 0;
					if (j < nodims - 1) {
						key[j + 1] ++;
					}
				}
			}
			strcpy(buffer, "");
			/* format key attributes index them by j */
			for (j = 0; j < nodims; j++) {
				sprintf(tempbuf, "%d", key[j]);
				fmt_attr(tempbuf, rels[relno].attrs[j].len, 0, fmt);
				strcat(buffer, tempbuf);
			}

			if ( line > 0 ) {
				val = log(line);
			} else {
				val = 0;
			}
			/* 
			 * format val attribute - dont increment j  
			 * as its 1 bigger than nodims as it exits the above loop
			 */
			sprintf(tempbuf, "%d", val);
			fmt_attr(tempbuf, rels[relno].attrs[j].len, 0, fmt);
			strcat(buffer, tempbuf);

			/* random text for a filler */
			for (i = 0; i < FILLEN; i++) {
				filbuf[i] = (char)(CHRST + random() % CHROFF);
			}
			filbuf[i] = '\0';

			/* format fil attribute - increment j  */
			j++;
			fmt_attr(filbuf, rels[relno].attrs[j].len, 1, fmt);
			strcat(buffer, filbuf);
			strcat(buffer, "\n");

			if( write(fd, buffer, strlen(buffer)) == -1 ) {
				perror("failed to write");
				return 2;
			}
			key[k]++;
			line++;
		}
	} 
	

	free(buffer);
	free(tempbuf);
	free(filbuf);

	close(fd);
	free(factfile);

	free(key);
	free(keylim);

	return 0;
}


/*
 * write the relation files on a specified size on the path
 */
int	write_dat(float size, char *path, int fmt) {

	Rel		*rels;
	int		i;

	/*
	 *  initialize random stuff
	 */
	srandom(getpid());


	/*
	 * iterate through the relations
	 */
	rels = getrels();
	for (i = 0; i < NORELS; i++) {
		if (strcmp(rels[i].type, "timelike dimension") == 0 ||
			strcmp(rels[i].type, "dimension") == 0) {
			if (write_dim(rels, i, size, path, fmt) != 0) {
				perror("failed to write dimension");
				return 1;
			}
		} else {
			if (write_fact(rels, i, size, path, fmt) != 0) {
				perror("failed to write fact");
				return 1;
			}

		}
	}


	freerels(rels);


return 0;
}


/*
 * show run options
 */
void	usage() {

	printf("datagen -s size -d directory -m fixed|del\n");
	return;
}


/*
 * main entry point
 */
int		main(int argc, char** argv) {


	int		option;		

	float	data_size = 1.0;
	char	*data_path = ".";
	int		data_fmt = DEL;

	/* 
	 * get and check options 
	 */

	while ((option = getopt(argc, argv, "d:s:m:")) != -1)  {
		switch(option) {
			case 'd':
				data_path = malloc(strlen(optarg) + 1);
				strcpy(data_path, optarg);
				break;
			case 's':
				data_size = atof(optarg);
				break;
			case 'm':
				if (strcmp(optarg, "fixed") == 0) {
					data_fmt = FIX;
				}
				break;
			default:
				usage(argv[0]);
				return 1;
		}
	}
	argc -= optind;
	argv += optind;

	/*
	 * get started
	 */
	printf("datagen : creating data set\n");
	printf("        : size = %.1f on path %s\n", data_size, data_path);

	printf("        : writing data files\n");
	if (write_dat(data_size, data_path, data_fmt) != 0) {
		fprintf(stderr, "bailing out writing data files\n");
		return 1;
	}


	return 0;
}
