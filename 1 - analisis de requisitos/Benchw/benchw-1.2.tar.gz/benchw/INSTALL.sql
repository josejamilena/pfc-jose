Benchw Installation Instructions - Microsoft SQL Server
================================

Version 2000


1 Database Optimizations
========================

Fixed memory size		= 100M
?sort

2 Dataset and Script Creation
=============================

Firstly get and install Mingw and Msys (http://www.mingw.org).

Run a Msys command window:
$ tar -zxvf benchw-<version>.tar.gz
$ cd benchw
$ ./configure --prefix="c:/program files/benchw"
$ make
$ make install

now amend the system path to include "c:\program files\benchw\bin" -
alternatively skip 'make install' and run from the build directory 
if it is desired to *not* mess about with the windows path.

Lets write the dump files in "c:/benchw/dump" and the scripts in 
"c:/benchw/scripts".

$ cd c:/benchw/scripts
$ datagen -d "c:/benchw/dump"
$ schemagen -d "c:/benchw/scripts"
$ querygen -d "c:/benchw/scripts" 


3 Database Preparation
======================

Run "Enterprise Manager" and create a database benchw. It is necessary to
allow the data file to grow to 2G and the transaction log to 4G.
Run "Sql Analyzer" and execute the script "schema.sql"

4 Running The Tests
===================

Run "import and Export Data" and import the "dim[0-2].dat" and "fact0.dat" files
Run "Sql Analyzer" and execute the script "indexes.sql"
Run "Sql Analyzer" and execute the query scripts "qtype[0-4].sql"

