/*
 * qry.c	: basic utilities for getting and setting query structures
 *
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 */

/*
 * autoconf includes
 */
#include "config.h"


/*
 * constants data generation
 */
#include "dat.h"

  
/*
 * relation structures
 */
#include "rel.h"


/*
 * query structures
 */
#include "qry.h"

  
/*
 * set query details
 *
 * construct the elements of a query :
 * relations, joins , projections, restrictions
 */
void		setqrydets(Qry *qrys, int qryno, int syear, int sdelta){

	int		i;
	int		attid;
	int		noattrs;
	Rel		*rels;
	Attr	*attrs;
	Attr	*toattrs;
	Qryrel	*qryrels;
	Qryjoin	*qryjoins;
	Qryproj	*qryprojs;
	Qryrest	*qryrests;
	int		lvar, rvar;
	

	/* get the relation structures */
	rels = getrels();

	
	/* set the number of relations in a query */
	if ( qrys[qryno].no == (NOQRYS - 1) || qrys[qryno].no == 0) {
		qrys[qryno].norels = 2;
	} else {
		qrys[qryno].norels = qryno + 1;
	}

	/* allocate storage for them */
	qryrels = malloc(qrys[qryno].norels * sizeof(Qryrel));


	/* determine the query relations */
    for (i = 0; i < qrys[qryno].norels; i++) {
		if ( i == qrys[qryno].norels - 1 || qrys[qryno].norels == 1) {
			strcpy(qryrels[i].name, rels[NORELS - 1].name);
			strcpy(qryrels[i].alias, "f");	
		} else {
			strcpy(qryrels[i].name, rels[i].name);
			sprintf(qryrels[i].alias, "d%d", i);
		}

	}

	qrys[qryno].rels = qryrels;

	
	/* allocate storage for the joins - 1 less than the number of relations */
	qryjoins = malloc((qrys[qryno].norels - 1)* sizeof(Qryjoin));

	/*
	 * join each dimension to the fact relation
	 * use the first attribute of each dimension as the join key
	 * and the ith attribute of the fact relation as the other join key.
	 *
	 * note that it is assumed that the last relation is the "fact".
	 * changing this will require more sophisticated code to determine
	 * this based on the relation type...lazyness alert here :-)
	 */
	for (i = 0; i < qrys[qryno].norels; i++ ) {
		
		attrs = getrelattrsbyname(qryrels[i].name, rels);
		toattrs = getrelattrsbyname(rels[NORELS - 1].name, rels);
		
		if ( strcmp(qryrels[i].alias, "f") != 0 ) {
			strcpy(qryjoins[i].fromalias, qryrels[i].alias);
			strcpy(qryjoins[i].toalias, "f");
			strcpy(qryjoins[i].fromattr, attrs[0].name);
			strcpy(qryjoins[i].toattr, toattrs[i].name); 
			
		}
	}
	qrys[qryno].joins = qryjoins;

	
	/*
	 * set the projections
	 *
	 * set the number of projections to the the number of relations in
	 * the query.
	 *
	 */
	qrys[qryno].noprojs = qrys[qryno].norels;
	qryprojs = malloc(qrys[qryno].noprojs * sizeof(Qryproj));
	for  (i = 0; i < qrys[qryno].noprojs; i++ ) {

		/*
		 * get the alias, attribute structure and number of attributes
		 * for each relation to be projected
		 * if the projection involves a function, then
		 * indicate this with the aggregate flag.
		 */
		strcpy(qryprojs[i].alias, qrys[qryno].rels[i].alias);
		attrs = getrelattrsbyname(qrys[qryno].rels[i].name, rels);
		noattrs = getrelnoattrsbyname(qrys[qryno].rels[i].name, rels);

		if ( i == qrys[qryno].noprojs - 1 ) {
			attid = noattrs - 2;
			strcpy(qryprojs[i].funct, "count");
			qryprojs[i].isagg = 1;
			strcpy(qryprojs[i].attr, attrs[attid].name);
		} else if ( i == 0 && qryno != NOQRYS - 1) {
			attid = noattrs - 2;
			strcpy(qryprojs[i].funct, "");
			qryprojs[i].isagg = 0;
			strcpy(qryprojs[i].attr, attrs[attid].name);
		} else {
			attid = noattrs - 3;
			strcpy(qryprojs[i].funct, "");
			qryprojs[i].isagg = 0;
			strcpy(qryprojs[i].attr, attrs[attid].name);
		}
		
	}
	qrys[qryno].projs = qryprojs;


	/*
	 * set the restrictions
	 *
	 * create one restriction for each dimension relation in the query,
	 * again assume that relations are added to the the query with the
	 * "fact" last.
	 * decide which attribute to use in each restriction, then set the 
	 * "left hand side" operators/variables as appropriate.
	 *
	 */
	qrys[qryno].norests = qrys[qryno].norels - 1;
	qryrests = malloc(qrys[qryno].norests * sizeof(Qryrest));
	for  (i = 0; i < qrys[qryno].norests; i++ ) {

		/* the alias */
		strcpy(qryrests[i].alias, qrys[qryno].rels[i].alias);

		/* the number of attributes and the structure itself*/
		attrs = getrelattrsbyname(qrys[qryno].rels[i].name, rels);
		noattrs = getrelnoattrsbyname(qrys[qryno].rels[i].name, rels);

		/* the attribute */
		if (i == 0 && qryno == 0) {
			attid = noattrs - 4;
		} else if (i == 0 || qryno == NOQRYS - 1 ) {
			attid = noattrs - 3;
		} else {
			attid = noattrs - 2;
		}

		/* the operators and variables for the 'left hand side'*/
		strcpy(qryrests[i].attr, attrs[attid].name);
		if ( i == 0 && qryno == NOQRYS - 1) {
			lvar = syear + (sdelta % 20) + 10;
			strcpy(qryrests[i].op, "<");
			sprintf(qryrests[i].val, "%d", lvar);
		} else if (i == 0 && qryno == 0 ) {
			lvar = syear + (sdelta % 20) + 10;
			rvar = MDAY;
			strcpy(qryrests[i].op, "BETWEEN");
			sprintf(qryrests[i].val, "'%d-01-01' AND '%d-12-%d'",
					lvar, lvar, rvar);
		} else if (i == 0 && qryno < 2 ) {
			lvar = syear + (sdelta % 20) + 10;
			strcpy(qryrests[i].op, "=");
			sprintf(qryrests[i].val, "%d", lvar);
		} else if (i == 0 && qryno >= 2 && qryno < NOQRYS - 1) {
			lvar = syear + (sdelta % 20) + 10;
			rvar = syear + (sdelta % 20) + 15;
			strcpy(qryrests[i].op, "BETWEEN");
			sprintf(qryrests[i].val, "%d AND %d", lvar, rvar);
		} else if ( i == 1 && qryno >= 2) {
			lvar = (sdelta % 20) + DIMTYP /  10;
			rvar = (sdelta % 20) + 1.4 * (DIMTYP / 10)  ;
			strcpy(qryrests[i].op, "BETWEEN");
			sprintf(qryrests[i].val, "'%dth measure type' AND '%dth measure type'",
					lvar, rvar);
		} else {
			lvar = (sdelta) % 6 + DIMTYP / 100;
			rvar = (sdelta) % 6 + (DIMTYP / 100) + 3;
			strcpy(qryrests[i].op, "BETWEEN");
			sprintf(qryrests[i].val, "'%dth measure type' AND '%dth measure type'",
					lvar, rvar);
		}
		
		
	}
	
	qrys[qryno].rests = qryrests;
	
	freerels(rels);
	
	return;               
}


/*
 * setup the query structures
 *
 * create an array of query variants (i.e repeating queries)
 * create and set the details for each *individual* query,
 * and attach a "set" (i.e NOQRYS) of these queries to each query variant.
 */
Qry			**getqrys( int repeats ) {

	int		i,v;
	Qry		*qrys;
	Qry		**qryvariants;


	/* allocate memory for array of query variants */
	qryvariants = malloc(repeats *sizeof(*qrys));

	for (v =0; v < repeats; v++) {

		/* allocate enough storage for NOQRYS queries */
		qrys = malloc(NOQRYS * sizeof(Qry));

		/* set the details for each one */
		for (i = 0; i < NOQRYS; i++) {
			sprintf(qrys[i].name, "query%d", i);
			qrys[i].no = i;
			setqrydets(qrys, i, SYEAR, v );
		}

		qryvariants[v] = qrys;
	}

	return qryvariants;
}


/*
 * free the query structures
 *
 * first free the rels, joins, projections and restrictions,
 * the free the (individual) query(s) itself
 * then finally the query variant (repeating) array.
 */
void	freeqrys(Qry **qryvariants, int repeats) {
	int		i;
	int		v;
 	Qry		*qrys;

	for ( v = 0; v < repeats; v++) {

		qrys = qryvariants[v];

		for ( i = 0; i < NOQRYS; i++) {
			free(qrys[i].rels);
			free(qrys[i].joins);
			free(qrys[i].projs);
			free(qrys[i].rests);
		}

		free(qrys);
	}

	free (qryvariants);    

 	return;
}

