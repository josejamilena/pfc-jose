/*
 * sch.h	: includes for schema generator
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 */
#ifndef SCH_H
#define SCH_H

#define SCHFILE		"schema.sql"
#define INDFILE		"indexes.sql"

#endif /* SCH_H */
