/*
 * lod.h	: includes for load generator
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 */
#ifndef LOD_H
#define LOD_H

#define LODFILE		"load.sql"
#define TDSVERSION	"10.0"

#endif /* LOD_H */
