/*
 * qry.h	: defines and constants for queries
 *
 * by Mark Kirkwood (markir@paradise.net.nz)
 */
#ifndef QRY_H
#define QRY_H


/* number of queries etc */
#define QRYFILE			"qtype"
#define NOQRYS			(NORELS + 1)
#define VALSIZ			100

/* workaround for buggy servers that cannot handle AS in from clause */
#define NOAS			0
#define AS				1

/* use a symbolic constant for 'all' */
#define ALL				-1


/* query join*/
typedef struct _Qryjoin {
	char		fromalias[IDSIZ];	/* from alias of attribute */
	char		toalias[IDSIZ];		/* to alias of attribute */
	char		fromattr[IDSIZ];	/* from attribute */
	char		toattr[IDSIZ];		/* to attribute */
} Qryjoin;


/* query select list element */
typedef struct _Qryproj {
	char		alias[IDSIZ];		/* alias of attribute */
	char		attr[IDSIZ];		/* alias of attribute */
	char		funct[IDSIZ];		/* function to use on the attribute */
	int			isagg;				/* is the function an aggregate? */
} Qryproj;


/* query non join where */
typedef struct _Qryrest {
	char		alias[IDSIZ];		/* alias for the attribute */
	char		attr[IDSIZ];		/* the attribute */
	char		val[VALSIZ];		/* bind value to use */
	char		op[IDSIZ];			/* operator or functions*/
}  Qryrest;


/* query relation structure */
typedef struct _Qryrel {
	char		name[IDSIZ];		/* the relation name */
	char		alias[IDSIZ];		/* its alias */
} Qryrel;


/* query structure */
typedef struct _Qry {
	char	name[IDSIZ];			/* query name */
	int		no;						/* its number */
	int		norels;					/* how many relations */
	int		noprojs;				/* how many projections */
	int		norests;				/* how many restrictions */
	Qryrel	*rels;					/* the relation structures */
	Qryjoin	*joins;					/* joins */
	Qryproj	*projs;					/* projections */
	Qryrest	*rests;					/* restrictions */
} Qry;


/* interface to get and set queries and their detail structures */
void	setqrydets(Qry *qrys, int qryno, int syear, int sdelta);
Qry		**getqrys(int repeats);
void	freeqrys(Qry **qrys, int repeats);          


#endif /* QRY_H */
