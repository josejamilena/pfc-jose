/*
 * dat.h	: defines and constants for data creation
 *
 * by Mark Kirkwood (markir@paradise.net.nz)
 */
#ifndef DAT_H
#define DAT_H

/* constants to determine dataset size */
#define SCALE			10000
#define MDAY			28
#define SYEAR			2000
#define DIMTYP			100

/* constants for dimension strings */
#define DIMF1			"th interesting measure"
#define DIMF2			"th measure type"
#define FILLEN			96	

/* constants for random charactors */
#define CHRST			(97)
#define CHROFF			(26)

/* constants for file format type */
#define DEL				(0)
#define FIX				(1)

#endif /* DAT_H */
