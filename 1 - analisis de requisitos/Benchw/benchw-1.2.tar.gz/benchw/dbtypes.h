/*
 * dbtypes.h	: includes for load generator
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 */
#ifndef DBTYPES_H
#define DBTYPES_H

/* the various database managers */
#define PG			0
#define MY			1
#define DB2			2
#define ORA			3
#define SAP			4
#define FB			5
#define SQL			6
#define SYB			7

#endif /* DBTYPES_H */
