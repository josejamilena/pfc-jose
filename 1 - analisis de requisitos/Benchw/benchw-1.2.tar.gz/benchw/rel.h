/*
 * rel.h	: includes for relation structures
 *
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 */
#ifndef REL_H
#define REL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* identifier size */
#define	IDSIZ		20


/* relation number */
#define NORELS		4


/* attribute */
typedef struct _Attr {
	char	name[IDSIZ];	/* attribute name */
	char	type[IDSIZ];	/* datatype */
	int		len;			/* length */
	int		islenvis;		/* does length appear in definition ?*/
	int		iskey;			/* is (part of) primary key */
} Attr;


/* relation */
typedef struct _Rel {
	char	name[IDSIZ];	/* relation name */
	char	type[IDSIZ];	/* star schema component type */
	int		noattrs;		/* how many attributes */
	Attr	*attrs;			/* attribute structure */
} Rel;


/* interface to get and set */
void		setrelattrs(Rel *rels, int relno);
Rel			*getrels();
Attr		*getrelattrsbyname(char *name, Rel *rels);
int			getrelnoattrsbyname(char *name, Rel *rels);
int			getreltotalattrslen(Rel *rels, int relno);
int			getrelmaxattrslen(Rel *rels, int relno);
void		freerels(Rel *rels);

#endif /* REL_H */
