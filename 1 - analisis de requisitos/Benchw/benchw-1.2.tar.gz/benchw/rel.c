/*
 * rel.c	: basic utilities for getting and setting relation structures
 *
 * by Mark Kirkwood (markir@paradise.net.nz)
 *
 * Bugs 	: bit lax about return code from malloc's...
 */


/*
 *
 */
#include "config.h"


/*
 * relation includes
 */
#include "rel.h"


/*
 * create an attribute structure for a relation.
 *
 * there are two basic types of relation : dimension and fact.
 * there are two types of dimension : timelike and not timelike.
 *
 * note that we are passed a pointer to the entire relation collection,
 * and so could probably do them all in one go. however, it seemed clearer
 * to make this function set the attributes on only 1 relation at a time.
 */
void		setrelattrs(Rel *rels,int relno) {

	int		i;
	Attr	*attrs;


	/*
	 * decide what sort of relation we have been asked to setup
	 */
	if (strcmp(rels[relno].type, "timelike dimension") == 0) {
		rels[relno].noattrs = 5;
		attrs = malloc(rels[relno].noattrs * sizeof(Attr));

		for (i = 0; i < rels[relno].noattrs; i++) {
			switch (i) {
			case 0 :
				sprintf(attrs[i].name, "%s%d%s", "d", relno, "key");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 1;
				break;
			case 1 :
				strcpy(attrs[i].name, "ddate");
				strcpy(attrs[i].type, "DATE");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 0;
				break;
			case 2 :
				strcpy(attrs[i].name, "dyr");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 0;
				break;
			case 3 :
				strcpy(attrs[i].name, "dmth");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 0;
				break;
			case 4 :
				strcpy(attrs[i].name, "dday");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 0;
				break;
			}
		}

	} else if (strcmp(rels[relno].type, "dimension") == 0) {
		rels[relno].noattrs = 4;
		attrs = malloc(rels[relno].noattrs * sizeof(Attr));
		for (i = 0; i < rels[relno].noattrs; i++) {
			switch (i) {
			case 0 :
				sprintf(attrs[i].name, "%s%d%s", "d", relno, "key");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 1;
				break;
			case 1 :
				strcpy(attrs[i].name, "dat");
				strcpy(attrs[i].type, "VARCHAR");
				attrs[i].len = 100;
				attrs[i].islenvis = 1;
				attrs[i].iskey = 0;
				break;
			case 2 :
				strcpy(attrs[i].name, "dattyp");
				strcpy(attrs[i].type, "VARCHAR");
				attrs[i].len = 20;
				attrs[i].islenvis = 1;
				attrs[i].iskey = 0;
				break;
			case 3 :
				strcpy(attrs[i].name, "dfill");
				strcpy(attrs[i].type, "VARCHAR");
				attrs[i].len = 100;
				attrs[i].islenvis = 1;
				attrs[i].iskey = 0;
				break;
			}
		}
	} else {
		/*
		 * relation is a fact
		 */
		rels[relno].noattrs = NORELS + 1;
		attrs = malloc(rels[relno].noattrs * sizeof(Attr));
		for (i = 0; i < rels[relno].noattrs; i++) {
			if ( i < NORELS - 1) { 		// foreign keys
				sprintf(attrs[i].name, "%s%d%s", "d", i, "key");
				strcpy(attrs[i].type, "INTEGER");
				attrs[i].len = 10;
				attrs[i].islenvis = 0;
				attrs[i].iskey = 1;
			} else {					// remaining attributes
				switch (i) {
				case NORELS - 1 :
					strcpy(attrs[i].name, "fval");
					strcpy(attrs[i].type, "INTEGER");
					attrs[i].len = 10;
					attrs[i].islenvis = 0;
					attrs[i].iskey = 0;
					break;
				case NORELS :
					strcpy(attrs[i].name, "ffill");
					strcpy(attrs[i].type, "VARCHAR");
					attrs[i].len = 100;
					attrs[i].islenvis = 1;
					attrs[i].iskey = 0;
					break;
				}
			}
			
		}
	}

	/*
	 *  assign the sttribute structure
	 */
	rels[relno].attrs = attrs;
	return;
}


/*
 * setup relation structure for the collection of relations.
 *
 * firstly allocated enought space for NORELS relation structures.
 * then set each relation's properties - like whether its a dimension or
 * not etc.
 *
 * for each one set its attributes.
 *
 * finally return (a pointer to) the relation structure
 */
Rel		*getrels() {

	int		i;
	Rel		*rels;

	rels = malloc(NORELS * sizeof(Rel));

	for (i = 0; i < NORELS; i++) {
		if ( i < NORELS -1 ) {		// dimension
			sprintf(rels[i].name, "%s%d", "dim", i);
			if ( i == 0 ) {
				strcpy(rels[i].type, "timelike dimension");
			} else {
				strcpy(rels[i].type, "dimension");
			}
			setrelattrs(rels, i);
		} else {					// fact
			strcpy(rels[i].name, "fact0");
			strcpy(rels[i].type, "fact");
			setrelattrs(rels, i);			
		}
	}
	return rels;
}


/*
 * given the name of a relation, return (a pointer to ) its
 * attribute structure
 */
Attr	*getrelattrsbyname(char *name, Rel *rels){
	int		i;

	
	for ( i = 0; i < NORELS; i++) {
		if ( strcmp(rels[i].name, name) == 0) {
			return rels[i].attrs;
		}
	}

	return NULL;
}


/*
 * return the number of attributes for a given ralation name
 */
int			getrelnoattrsbyname(char *name, Rel *rels){
	int		i;

	
	for ( i = 0; i < NORELS; i++) {
		if ( strcmp(rels[i].name, name) == 0) {
			return rels[i].noattrs;
		}
	}

	return 0;
}


/*
 * return the totaled maximum possible size of attributes in a relation
 */
int			getreltotalattrslen(Rel *rels, int relno) {
	int		i;
	int		totlen = 0;

	for (i = 0; i < rels[relno].noattrs; i++) {
		totlen = totlen + rels[relno].attrs[i].len;
	}

	return totlen;
}


/*
 * return the maximum possible size of any attribute in a relation
 */
int			getrelmaxattrslen(Rel *rels, int relno) {
	int		i;
	int		maxlen = 0;

	for (i = 0; i < rels[relno].noattrs; i++) {
		if (rels[relno].attrs[i].len > maxlen) {
			maxlen =  rels[relno].attrs[i].len;
		}
	}

	return maxlen;
}


/*
 * free up the relation structure,
 * firstly , free the attribute structure
 * and then free the relattion itself
 */
void		freerels(Rel *rels) {
	int		i;


	for ( i = 0; i < NORELS; i++) {
		free(rels[i].attrs);

	}

	free(rels);

	
	return;
}


