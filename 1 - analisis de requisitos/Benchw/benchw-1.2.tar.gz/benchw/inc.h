/*
 * inc.h	: includes required plus some convenient defines
 * 
 * by Mark Kirkwood (markir@paradise.net.nz)
 */
#ifndef INC_H
#define INC_H


/*
 * autoconf defines
 */
#include "config.h"

/* required includes */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <math.h>

/* handle platforms without random() */
#ifndef HAVE_RANDOM
#define random() rand()
#define srandom(seed) srand(seed)
#endif

/* file opening options and bitmasks */
#define OPENOPTS		O_CREAT|O_TRUNC|O_RDWR
#define APPENDOPTS		O_CREAT|O_APPEND|O_RDWR
#define OPENFLGS		0664

#endif /* INC_H */
