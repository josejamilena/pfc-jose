#!/usr/bin/perl
#***************************************************************************
#                  osdb.pl  -  OSDB Driver Program
#                     -------------------
#    begin        : Fri Dec  1 09:23:32 EST 2000
#    copyright    : (C) 2000 by Andy Riebs and Compaq Computer Corporation
#    email        : andy.riebs@compaq.com
#**************************************************************************/
use Benchmark;
use osdb_postgres;
use Getopt::Long;
use Time::HiRes qw(usleep ualarm gettimeofday);
use POSIX ":sys_wait_h";
use Parallel::ForkManager;
$FILENAME_HUNDRED   = "asap.hundred";
$FILENAME_TENPCT    = "asap.tenpct";
$FILENAME_TINY      = "asap.tiny";
$FILENAME_UNIQUES   = "asap.uniques";
$FILENAME_UPDATES   = "asap.updates";
$FILENAME_MAX_LENGTH=12;
$DBNAME		 = "osdb_test";
#
#*************************************************************************
#*                                                                         *
#*  This program is free software; you can redistribute it and/or modify   *
#* it under the terms of the GNU General Public License as published by   *
#*  the Free Software Foundation; either version 2 of the License, or      *
#*  (at your option) any later version.                                    *
#*                                                                         *
#*  This program is distributed in the hope that it will be useful,        *
#*  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
#*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
#*  GNU General Public License for more details.                           *
#*                                                                         *
#*  You should have received a copy of the GNU General Public License      *
#*  along with this program; if not, write to the Free Software Foundation,*
#*  Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA          *
#*************************************************************************
#/

#
#Log: osdb.c,v $
#Revision 1.25  2004/10/12 13:00:00  fpantaleo
#Rewrite and port to perl perl/dbi

#Revision 1.24  2002/03/13 00:09:51  ariebs
#Print the waitpid() return value on failure in step 8 like in step 2 of #the multiuser tests.

#Revision 1.23  2002/03/12 03:58:34  ariebs
#Clean up the usage() message formatting.

#Revision 1.22  2002/03/07 11:45:09  ariebs
#Add the infrastructure to allow product-specific run-time options.

#Revision 1.21  2002/01/29 00:10:13  ariebs
#Apply Peter Eisentraut's portability patches.

#Revision 1.20  2001/10/10 02:51:13  ariebs
#Implement --strict_conformance option, allowing implementers to skip or work around missing features #(e.g. PostgreSQL prefers not to use HASH indexes) -- the default is FALSE, i.e., allow work arounds

#Revision 1.19  2001/09/13 08:05:30  vapour
#Replaced the --nogeneratedata option with --generate and --size n.  Improved the output readability.

#Revision 1.18  2001/09/12 05:11:12  vapour
#Started adding structures for --nogeneratedata & improved output readability

#Revision 1.17  2001/09/09 06:05:32  vapour
#Updated the braces to follow the OSDB Style Guide recommendations

#Revision 1.16  2001/08/17 01:18:22  ariebs
#Set routineName="mu_oltp_update()", as appropriate, to report more #helpful error messages when deadlocks occur

#Revision 1.15  2001/08/15 21:45:16  ariebs
#Include --help as a synonym for --usage

#Revision 1.14  2001/07/25 01:40:48  ariebs
#Replace the obsolete "CLK_TCK" with a call to sysconf(_SC_CLK_TCK)

#Revision 1.13  2001/04/14 16:02:36  ariebs
#Fix the fix: "--osdblogfile" resulted from the blind change of "log" #to "osdblog"...

#Revision 1.12  2001/04/13 15:46:20  ariebs
#Mass change of global "log" to "osdblog" to avoid namespace collision #with Informix

#Revision 1.11  2001/03/28 00:06:33  ariebs
#Reflect the decision to separate program-control.c from osdb.c

#Revision 1.10  2001/03/25 12:46:15  ariebs
#Clean up programFeed2()'s --watch output to show both strings #concatenated on a single line to better reflect what is getting #passed to the program.

#Revision 1.9  2001/03/22 02:40:25  ariebs
#It seems that some programs may need .005 of a second to complete #their output before they terminate (search for "tv.rv_usec=5000"). #This algorithm seems to work OK, but I'm still not real happy with it.

#Revision 1.8  2001/03/18 02:40:32  ariebs
#Add support for osdb-inf-ui

#Revision 1.7  2001/03/15 03:37:24  ariebs
#Seems we can safely wait just 1/1000 of a second to ensure that we've #got all output from a child process

#Revision 1.6  2001/03/11 20:40:53  ariebs
#Fix programGetOutput() to eliminate the 5-10 second/test penalty

#Revision 1.5  2001/02/23 20:38:27  ariebs
#Cosmetic changes to
#(a) Use forkpty() (so I added LDFLAGS to all the makefiles while I was
#    at it, and
#(b) Add "diagnostics()" to osdb.c (which perturbed most programs)

#Revision 1.3  2001/02/21 03:40:50  ariebs
#Make programStartPipe() and osdb-my-ui work better together (but still a #couple of problems to go)

#Revision 1.2  2001/02/18 14:30:30  ariebs
#Implement programStartPty() for MySQL, and eliminate my hideous patch #for the mysql program. Also renamed "programStart()" to #"programStartPipe()"

#*/

$MYDOC = <<EOF;

/*
 * This program implements OSDB, "the Open Source Database
 * Benchmark," which is based on the "ANSI SQL Standard Scalable
 * and Portable Benchmark for Relational Database Systems," as
 * described at <http://www.benchmarkresources.com/handbook/5.html>.
 *
 * The paper at that URL, written by Carolyn Turbyfill, Cyril Orji,
 * and Dina Bitton, seems to be the 2nd draft of a chapter that was
 * (will be?) used in Jim Gray's "Benchmark Handbook." Currently
 * out of print (as of November, 2000), it appears that Morgan
 * Kaufmann Publishers plan to update or reissue it in the near
 * future. For the moment (01 December 2000), the Web site at
 * <http://www.benchmarkresources.com/handbook/introduction.asp>
 * is "please to present this online book, The Benchmark Handbook,
 * Edited by Jim Gray free of charge to our readers."
 *
 * Signal usage
 *
 *   SIGCHLD is handled to acknowledge the termination of subprocesses;
 *   this is required in order for waitpid() to be useful.
 *
 *   SIGHUP -- the parent process uses SIGHUP to indicate that the
 *   children should terminate at the conclusion of their current loop.
 *   It is also used to tell everyone to go away if anyone encounters
 *   a fatal error.
 *
 * formatting note
 *
 *    We use the vim commands "ts=4" (tabstop=4) and "et" (expand
 *    tabs to spaces) to try to ensure readable, consistent formatting.
*/

EOF

sub crossSectionTests {
    my ($mode)=($_[0]);
    $startTime=0;
    $elapsed=0;
    $t="";

    $cst_startTime=gettimeofday;
    timeIt("sel_1_ncl()","sel_1_ncl");
    timeIt("agg_simple_report()","agg_simple_report");
    timeIt("mu_sel_100_seq()","mu_sel_100_seq");
    timeIt("mu_sel_100_rand()","mu_sel_100_rand");
    timeIt("mu_mod_100_seq_abort()","mu_mod_100_seq_abort");
    timeIt("mu_mod_100_rand()","mu_mod_100_rand");
    timeIt("mu_unmod_100_seq()","mu_unmod_100_seq");
    timeIt("mu_unmod_100_rand()","mu_unmod_100_rand");
    $cst_elapsed=gettimeofday-$cst_startTime;
    print "$mode CrossSectionTests\t$cst_elapsed seconds\n";
}

sub diagnostics() {
    if (errno) {
        print("perror reports");
	}
}

sub elapsedTime {
    local ($T)=($_[0]);
    $res[16];
    $seconds;
    $hours, $minutes;

    $hours=$T/(3600*$ticksPerSecond);
    $T=$T%(3600*$ticksPerSecond);
    $minutes=$T/(60*$ticksPerSecond);
    $seconds=(($T%(60*$ticksPerSecond)))/$ticksPerSecond;
    $res=("%d:%02d:%05.2f", $hours, $minutes, $seconds);
    return $res;
}

sub fieldHup {
    local ($sig)=($_[0]);
    if ($watch) {
        print("\nSIGHUP/SIGINT handler invoked: (%d)\n", $myPid);
    }
    if ($iAmParent) {
        if ($sig==SIGHUP) {
	    select stderr;
            printf "\n\nsomeone sighup'd the parent\n";
            exit(1);
        }
        # Hmmm... user must have interrupted us */
	select stderr;
        printf "\n\nTerminated by user\n";
        kill(getppid(),SIGHUP);
        sleep(5);
        exit(1);
    }
    $dontHangUp=0;
}

sub locked_pause() {
    $tv_sec=0;
    $tv_usec=RAND(50,1000);    #/* pause for .0005 to .001 seconds */
    #select(0, NULL, NULL, NULL, &tv);
    sleep $tv_usec;
}

#main(int argc, char* argv[]) {
    {
    print "starting\n";
    $elapsed;
    $clocks,
    $dbSize;
    $tmsStart,$tmsEnd;
    @argv=@ARGV;
    foreach $item (@argv) {
	++$argc;
	}

    $ticksPerSecond=60;
    $currentTest="Test Initialization";
    $myPid=$$;
    setDefaults($DBNAME,'data-40mb');
    parseCommands($argc, @argv);  
# Parse command-line options, exit if any are wrong, set variables appropriately */

    #/* Start of database table creation */

    if ($runCreate) {
        databaseCreate($DBNAME);
        databaseConnect();
        print("\n");  #/* Print a newline to enhance readability. JC */

        #/* Database data generation should go here */

	$popdb_clocks=gettimeofday;
        populateDataBase();
	$popdb_elapsed=gettimeofday-$popdb_clocks;
        databaseDisconnect();
        select osdblog;
        printf "\n\"populateDatabase Test\"\t%.02f second\n\n", $popdb_elapsed;
        FLUSH_LOG;
    }

    $currentTest="Counting tuples";
    databaseConnect();
    if (($tupleCount=countTuples("updates"))==0) {
        print "empty database -- empty results";
	exit(1);
	}

    $dbSize=(4*$tupleCount*100)/1000000;
        #/* dbSize: 4 relations, N tuples/relation, 100 bytes/tuple */
    select osdblog;
    printf "\n\"Logical database size %dMB\"\n\n", $dbSize;
    FLUSH_LOG;
    databaseDisconnect();

    #/* Start of the single user test */

    if ($runSingleUser) {
        $currentTest="Preparing single user test\n";
        $rsu_clocks=gettimeofday;
        singleUserTests();
        $rsu_elapsed=gettimeofday-$rsu_clocks;
	select osdblog;
        printf "\n\"Single User Test\"\t%.02f second\n\n", $rsu_elapsed;
        FLUSH_LOG;
    }

    #/* Start of the multi-user test */

    if ($runMultiUser) {
        $currentTest="Preparing multi-user test";
        databaseConnect();
        if ($tupleCount != countTuples("updates")) {
            print("data corrupted; skipping multi-user test");
	    exit(1);
        }
        databaseDisconnect();
        print("\nStarting multi-user test\n");
        $msu_clocks=gettimeofday;
        multiUserTests(($nUsers? $nUsers : $dbSize/4));
        $msu_elapsed=gettimeofday-$msu_clocks;
	select osdblog;
        printf "\n\"Multi-User Test\"\t%.02f seconds\n", $msu_elapsed;
	exit(0);
    }

    #/* End of the test */
    exit(0);
}

sub fork1 () {
	databaseConnect();
	runUntilHUP("mu_ir_select");
	databaseDisconnect();
	exit(0);
}

sub fork2 () {
	databaseConnect();
	runUntilHUP("mu_oltp_update");
	databaseDisconnect();
	exit(0);
}

sub multiUserTests {
    ($nInstances)=($_[0]);
    $fTime;
    $endOfTime,
    $i;
    $iters;
    $pStatus;
    $startOfTime,
    $timeToRun;
    $kid_pids,
    $pid;
    $tv;
    $t;

  $currentTest="Multi-user tests";
  select osdblog;
  printf "\"Executing multi-user tests with $nInstances user task\"\n";
  if ($nInstances) {
	if ($nInstances > 0) {}
	else {
		die "Bad parm of $nInstances";
	}
  }
  else {
	die "Bad parm of $nInstances";
  }

  #/* Step 1 -- start N instances of ir_select */

    my $pm = new Parallel::ForkManager($nInstances);
    #$pm->run_on_finish(sub { my ($pid, $exit_code) = @_;printf "** pool out PID $pid exit code: $exit_code\n";});
    #$pm->run_on_start(sub { my ($pid)=(@_[0]); printf "** started, pid: $pid\n";});
    {
	    my $pid = $pm->start and next;

	    databaseConnect(); 
	    mu_ir_select(); 
	    databaseDisconnect();
	    return;
	    $pm->finish;
    };

  #/* Step 3 -- run ir_select locally for 5 minutes, measure throughput */

    select osdblog;
    printf "Step 2:Run ir_select for 5 minutes\n";
    $timeToRun=($shortForm? 1 : 5);
    print osdblog "\nProceeding with 5 minute test\n";
    databaseConnect();
    $iters=0;
    $startOfTime=gettimeofday;
    $endOfTime=$startOfTime+($timeToRun+60);
    while (gettimeofday<$endOfTime) {
        mu_ir_select();
        $iters++;
    }
    $fTime=gettimeofday-$startOfTime;
    select osdblog;
    $tup_sec=$iters/$fTime; 
    $ir_time=$fTime/60.;
    printf "Mixed IR (tup/sec)\t$tup_sec\treturned in $ir_time minutes\n";

  #/* Step 4 -- run & time the "cross section" script */

    select osdblog;
    printf "Step 4:Cross section\n";
    crossSectionTests("Mixed IR");

  #/* Step 5 -- run queries to check integrity */

    select osdblog;
    printf "Step 5:Check integrity\n";
    timeIt("mu_checkmod_100_seq()","mu_checkmod_100_seq");
    timeIt("mu_checkmod_100_rand()","mu_checkmod_100_rand");
    databaseDisconnect();

  #/* Step 6 -- do some integrity tests */

    select osdblog;
    printf "Step 6:Integrity Tests\n";
  #$pm->wait_all_children;

  #/* Step 7 -- start N instances of oltp_update */

    select osdblog;
    printf "Step 7:Start $nInstances of oltp_update\n";
    my $pm = new Parallel::ForkManager($nInstances);  
    #$pm->run_on_finish(sub { my ($pid, $exit_code) = @_;printf "** pool out PID $pid exit code: $exit_code\n";});
    #$pm->run_on_start(sub { my ($pid)=@_; printf "** started, pid: $pid\n";});

    {
            my $pid = $pm->start and next;

            databaseConnect();
            mu_oltp_update();
            databaseDisconnect();
	    return;
            $pm->finish;
    };

  #/* Step 9 -- run ir_select locally again; measure throughput */

    select osdblog;
    printf "Step 9:Run ir_select\n";
    databaseConnect();
    $iters=0;
    $startOfTime=gettimeofday;
    $endOfTime=$startOfTime+($timeToRun+60);
    while (gettimeofday<$endOfTime) {
        mu_ir_select();
        $iters++;
    }
    $fTime=gettimeofday-$startOfTime;
    select osdblog;
    $tup_sec=$iters/$fTime;
    $mix_time=$fTime/60.;
    printf "Mixed OLTP (tup/sec)\t$tup_sec\treturned in $mix_time minutes\n";

  #/* Step 10 -- run & time the "cross section" script */

    select osdblog;
    printf "Step 10:Run cross section\n";
    crossSectionTests("Mixed OLTP");

  #/* Step 11 -- run some integrity tests */

    select osdblog;
    printf "Step 11:Run integrity tests\n";
    timeIt("mu_checkmod_100_seq()", "mu_checkmod_100_seq");
    timeIt("mu_checkmod_100_rand()", "mu_checkmod_100_rand");

  #/* Step 12 -- clean up and go home */

    select osdblog;
    databaseDisconnect();
}

sub parseCommands {
    my ($argc, @argv)=($_[0],@_[1]);
    $fileTest="";
    $i=0;
    $statBuf="";

    $shortForm = FALSE;
    $result = GetOptions ("users=i" => \$nUsers,    # numeric
                          "dataDir=s"   => \$dataDir,      # string
                          "logfile=s"   => \$logfile_name,      # string
                          "runcreate"  => \$runCreate,  # flag
                          "doindexes"  => \$doIndexes,  # flag
                          "runmulti"  => \$runMultiUser,  # flag
                          "runsingle"  => \$runSingleUser,  # flag
                          "short"  => \$shortForm,  # flag
                          "strict_conformance"  => \$strictConformance,  # flag
                          "usage"  => \$usage,  # flag
                          "help"  => \$usage,  # flag
                          "watch"  => \$watch,  # flag
                          "watchall"  => \$watchAll,  # flag
                          "verbose"  => \$verbose);  # flag

    if ($usage) {
	usage();
	exit(0);
	}

    if ($logfile_name) {
    	open (osdblog,'>$logfile_name') or die;
	}
    else {
    	open (osdblog,'>osdb.log') or die;
	}

    $SIG{SIGHUP} = sub{fieldHups;};
    $SIG{SIGINT} = sub{fieldHups;};

    select osdblog;
    printf "\"osdb\"\n\"Invoked: %s \n",@argv;
    if ($runMultiUser) {
	if ($nUsers) {
	   if ($nUsers > 1) {}
	   else {
    		printf "osdb was invoked with --runmulti invalid users parm\n";
		usage();
		exit(1);
	   }	
	}
	else {
		printf "osdb was invoked with --runmulti but missing users parm\n";
		usage();
		exit(1);
	}
    }

    if ($runCreate) {
	if ($runGenerate != TRUE) {  #/* Tests if we are generating test data or loading it */ 
            if ($dataDir == NULL) {
                $i = 50;
                $dataDir = $dataDir . "/data";
            }
	    else {
    		stat($dataDir, $statBuf) or die($dataDir);
        	$fileTest = $dataDir;
    		$fileTest= $fileTest . "/" . $FILENAME_HUNDRED;
	        stat($fileTest, $statBuf) or die("can't access data file");
  	        $fileTest = $dataDir;
    	        $fileTest=$fileTest . "/" . $FILENAME_TENPCT;
        	stat($fileTest, $statBuf) or die("can't access data file");
          	$fileTest= $dataDir;
	        $fileTest=$fileTest . "/" . $FILENAME_TINY;
    	        stat($fileTest, $statBuf) or die("can't access data file");
      	    	strcpy($fileTest, $dataDir);
        	$fileTest = $fileTest . "/" . $FILENAME_UNIQUES;
	        stat($fileTest, $statBuf) or die("can't access data file");
  	        $fileTest = $dataDir;
    	        $fileTest = $fileTest . "/" . $FILENAME_UPDATES;
        	stat($fileTest, $statBuf) or die("can't access data file");
          	free($fileTest);
		}
	}
    }	
}


sub populateDataBase() {
    timeIt("create_tables()","create_tables");
    timeIt("load()","load");
    timeIt("create_idx_uniques_key_bt()","create_idx_uniques_key_bt");
    timeIt("create_idx_updates_key_bt()","create_idx_updates_key_bt");
    timeIt("create_idx_hundred_key_bt()","create_idx_hundred_key_bt");
    timeIt("create_idx_tenpct_key_bt()","create_idx_tenpct_key_bt");
    timeIt("create_idx_tenpct_key_code_bt()","create_idx_tenpct_key_code_bt");
    timeIt("create_idx_tiny_key_bt()","create_idx_tiny_key_bt");
    timeIt("create_idx_tenpct_int_bt()","create_idx_tenpct_int_bt");
    timeIt("create_idx_tenpct_signed_bt()","create_idx_tenpct_signed_bt");
    timeIt("create_idx_uniques_code_h()","create_idx_uniques_code_h");
    timeIt("create_idx_tenpct_double_bt()","create_idx_tenpct_double_bt");
    timeIt("create_idx_updates_decim_bt()","create_idx_updates_decim_bt");
    timeIt("create_idx_tenpct_float_bt()","create_idx_tenpct_float_bt");
    timeIt("create_idx_updates_int_bt()","create_idx_updates_int_bt");
    timeIt("create_idx_tenpct_decim_bt()","create_idx_tenpct_decim_bt");
    timeIt("create_idx_hundred_code_h()","create_idx_hundred_code_h");
    timeIt("create_idx_tenpct_name_h()","create_idx_tenpct_name_h");
    timeIt("create_idx_updates_code_h()","create_idx_updates_code_h");
    timeIt("create_idx_tenpct_code_h()","create_idx_tenpct_code_h");
    timeIt("create_idx_updates_double_bt()","create_idx_updates_double_bt");
    timeIt("create_idx_hundred_foreign()","create_idx_hundred_foreign");
    return 0;
}


sub runUntilHUP() {
    local ($routine)=($_[0]);
    $SIG{SIGHUP} = sub{fieldHups;} or die("SIG_ERR, runUntilHUP");
    while ($dontHangUp) {
       @returned= &$routine();
    }
}

sub singleUserTests() {
    databaseConnect();
    timeIt("sel_1_cl()","sel_1_cl");
    timeIt("join_3_cl()","join_3_cl");
    timeIt("sel_100_ncl()","sel_100_ncl");
    timeIt("table_scan()","table_scan");
    timeIt("agg_func()","agg_func");
    timeIt("agg_scal()","agg_scal");
    timeIt("sel_100_cl()","sel_100_cl");
    timeIt("join_3_ncl()","join_3_ncl");
    timeIt("sel_10pct_ncl()","sel_10pct_ncl");
    timeIt("agg_simple_report()","agg_simple_report");
    timeIt("agg_info_retrieval()","agg_info_retrieval");
    timeIt("agg_create_view()","agg_create_view");
    timeIt("agg_subtotal_report()","agg_subtotal_report");
    timeIt("agg_total_report()","agg_total_report");
    timeIt("join_2_cl()","join_2_cl");
    timeIt("join_2()","join_2");
    timeIt("sel_variable_select_low()","sel_variable_select_low");
    timeIt("sel_variable_select_high()","sel_variable_select_high");
    timeIt("join_4_cl()","join_4_cl");
    timeIt("proj_100()","proj_100");
    timeIt("join_4_ncl()","join_4_ncl");
    timeIt("proj_10pct()","proj_10pct");
    timeIt("sel_1_ncl()","sel_1_ncl");
    timeIt("join_2_ncl()","join_2_ncl");
    timeIt("integrity_test()","integrity_test");
    timeIt("drop_updates_keys()","drop_updates_keys");
    timeIt("bulk_save()","bulk_save");
    timeIt("bulk_modify()","bulk_modify");
    timeIt("upd_append_duplicate()","upd_append_duplicate");
    timeIt("upd_remove_duplicate()","upd_remove_duplicate");
    #timeIt("upd_app_t_mid()","upd_app_t_mid");
    #timeIt("upd_mod_t_mid()","upd_mod_t_mid");
    #timeIt("upd_del_t_mid()","upd_del_t_mid");
    #timeIt("upd_app_t_end()","upd_app_t_end");
    #timeIt("upd_mod_t_end()","upd_mod_t_end");
    #timeIt("upd_del_t_end()","upd_del_t_end");
    #timeIt("create_idx_updates_code_h()","create_idx_updates_code_h");
    #timeIt("upd_app_t_mid()","upd_app_t_mid");
    #timeIt("upd_mod_t_cod()","upd_mod_t_cod");
    #timeIt("upd_del_t_mid()","upd_del_t_mid");
    #timeIt("create_idx_updates_int_bt()","create_idx_updates_int_bt");
    #timeIt("upd_app_t_mid()","upd_app_t_mid");
    #timeIt("upd_mod_t_int()","upd_mod_t_int");
    #timeIt("upd_del_t_mid()","upd_del_t_mid");
    #timeIt("bulk_append()","bulk_append");
    #timeIt("bulk_delete()","bulk_delete");
    databaseDisconnect();
}

sub timeIt {
    local ($rtnName,$routine)=($_[0],$_[1]);
    $theclocks=0;
    $retval=0;
    $start, $end;

    $currentTest=$rtnName;
    $testFailed=0;
    $theclocks=gettimeofday;
    $errno=0;
    $retval=&$routine();
    $clockdiff=gettimeofday-$theclocks;
    select osdblog;
    printf "%32s\t", $rtnName;  #/* Make the test outputs easier to read.  JC */
    if ($testFailed) {
	select osdblog;
        printf "failed\t(%.02f)\t%d\n",$clockdiff, $retval;
	}
    else {
	select osdblog;
        printf "%.02f seconds\treturn value = %d\n",$clockdiff, $retval;  
	}
	#/* Make the test outputs easier to read.  JC */
    FLUSH_LOG;
}

sub usage() { 
    print("Usage:\t  osdb\t[--generate | --datadir path] [--size n] [--short]\n\t\t[--watch] [--watchall] [--logfile file] [--users n]\n\t\t[--nocreate ] [--noindexes | --noindices ]\n\t\t[--nosingle] [--nomulti]\n");
    #argument_choices();
}

