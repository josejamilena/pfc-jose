package osdb_postgres;
use Exporter;
use DBI;
use Exporter ();
@ISA = qw(Exporter);
@EXPORT = qw(databaseConnect databaseCreate setDefaults create_tables load create_idx_uniques_key_bt create_idx_updates_key_bt create_idx_hundred_key_bt create_idx_tenpct_key_bt create_idx_tenpct_key_code_bt create_idx_tiny_key_bt create_idx_tenpct_int_bt create_idx_tenpct_signed_bt create_idx_uniques_code_h create_idx_tenpct_double_bt create_idx_updates_decim_bt create_idx_tenpct_float_bt create_idx_updates_int_bt create_idx_tenpct_decim_bt create_idx_hundred_code_h create_idx_tenpct_name_h create_idx_updates_code_h create_idx_tenpct_code_h create_idx_updates_double_bt create_idx_hundred_foreign databaseDisconnect countTuples sel_1_cl join_3_cl sel_100_ncl table_scan agg_func agg_scal sel_100_cl join_3_ncl sel_10pct_ncl simple_report agg_simple_report agg_info_retrieval agg_create_view agg_subtotal_report agg_total_report join_2_cl join_2 sel_variable_select_low sel_variable_select_high join_4_cl proj_100 join_4_ncl proj_10pct sel_1_ncl join_2_ncl integrity_test drop_updates_keys bulk_save updates_int_bt bulk_modify upd_append_duplicate upd_remove_duplicate mu_checkmod_100_rand mu_checkmod_100_seq mu_ir_select mu_mod_100_rand mu_mod_100_seq_abort mu_oltp_update mu_sel_100_rand mu_sel_100_seq mu_unmod_100_rand mu_unmod_100_seq);
$FILENAME_HUNDRED   = "asap.hundred";
$FILENAME_TENPCT    = "asap.tenpct";
$FILENAME_TINY      = "asap.tiny";
$FILENAME_UNIQUES   = "asap.uniques";
$FILENAME_UPDATES   = "asap.updates";
$FILENAME_MAX_LENGTH=12;
$OSDB_ERROR_error="";
$dataDir="";
$DBNAME="";
$MYDOC = <<EOF;
/***************************************************************************
                  postgres-call.c  -  PostgreSQL calls for OSDB/callable-sql
                     -------------------
    begin        : Fri Dec 1 2000
    copyright    : (C) 2000 by Andy Riebs and Compaq Computer Corporation
    email        : andy.riebs@compaq.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program; if not, write to the Free Software Foundation,*
 *  Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA          *
 **************************************************************************/

/*
$Log: osdb_postgres.pm,v $
Revision 1.1  2004/10/13 23:51:24  ariebs
Add Frank Pantaleo's Perl implementation of OSDB.


Revision 1.16  2004/10/12 13:00:00  fpantaleo
Rewrite and port to perl perl/dbi

Revision 1.15  2002/03/12 03:58:35  ariebs
Clean up the usage() message formatting.

Revision 1.14  2002/03/10 20:17:51  ariebs
Implement the --postgresql=no_hash_index option.

Revision 1.13  2002/03/07 11:45:09  ariebs
Add the infrastructure to allow product-specific run-time options.

Revision 1.12  2002/03/05 03:30:21  ariebs
Add a createTable() call in preparation for allowing database-specific syntax, e.g., mysql's "table=" options.

Revision 1.11  2002/01/29 00:10:14  ariebs
Apply Peter Eisentraut's portability patches.

Revision 1.10  2001/09/12 05:12:20  vapour
Changed some tests to be = TRUE instead of = 1

Revision 1.9  2001/09/09 07:00:26  vapour
Updated the braces to follow the OSDB Style Guide recommendations

Revision 1.8  2001/08/15 01:07:35  ariebs
Apply Maciej's fixes for foreign key support

Revision 1.7  2001/08/11 21:02:18  ariebs
Make all the cluster indexes unique (as they should have been -- Thanks Maciej!)

Revision 1.6  2001/04/13 15:46:21  ariebs
Mass change of global "log" to "osdblog" to avoid namespace collision with Informix

Revision 1.5  2001/02/23 20:38:27  ariebs
Cosmetic changes to
(a) Use forkpty() (so I added LDFLAGS to all the makefiles while I was
    at it, and
(b) Add "diagnostics()" to osdb.c (which perturbed most programs)

Revision 1.3  2001/02/18 14:34:50  ariebs
Clean out obsolete modification history

*/

EOF

#void interpretPGresult();

$cmd="";   #/* frequently used, but very transient */
$DB_CONNECT_CMD; #/* PQfinish() wants this string to exist! */ $NO_HASH_INDEX=FALSE; $PGresult; $PGconn;

sub TESTFAILED {
}

sub create_tables() {
    CREATE_TABLE('tiny', 'col_key numeric');
    CREATE_TABLE_STANDARD('uniques');
    CREATE_TABLE_STANDARD('updates');
    CREATE_TABLE_STANDARD('hundred');
    CREATE_TABLE_STANDARD('tenpct');
    return 0;
}

sub CREATE_TABLE {
	createTables("create table $_[0]( $_[1] )");
}

sub CREATE_TABLE_STANDARD {
    CREATE_TABLE("$_[0]",
       'col_key numeric,
        col_int numeric,
        col_signed numeric,
        col_float float,
        col_double float,
        col_decim numeric(18,2),
        col_date date,
        col_code char(10),
        col_name char(20),
        col_address varchar(80)');
}

sub BUGOUT {
	print "BUGOUT error: $_[0]\n";
}

sub argument_check()
{
    my ($arg) = ($_[0]);
    $i;
    $p;

    if (index($arg, "--postgresql=", 13)==0) {
        $p=$arg+13;
        if (index(p, "no_hash_index", 13)==0) {
            $NO_HASH_INDEX=TRUE;
            return(TRUE);
        }
    }
    return(FALSE);
}

sub argument_choices() {
    printf("\t\t[ --postgresql=no_hash_index ]\n");
}

sub bugout() {
    ($terminate, $stg, $fileName, $lineNo)=($_[0],$_[1],$_[2],$_[3]);
    fprintf(stderr,"\nError in test %s at (%d)%s:%d:\n... %s\n",
            $currentTest, getpid(), $fileName, $lineNo, $stg); 
    if ($PGRESULT) {
        fprintf(stderr, "PQresultStatus: %d\n", PQresultStatus(PGRESULT));
	}
    if (PQerrorMessage(PGCONN)) {
	    fprintf(stderr,"postgres reports: %s", PQerrorMessage(PGCONN));
	}
    diagnostics();
    if (++$failureCount >= $MAX_FAILURES) {
        $terminate = TRUE;  #/* Updated to be = TRUE.  JC */
        fprintf(stderr,"\nThreshold of %d errors reached.\n", $failureCount);
    }
    if ($terminate) {
        PQfinish(PGCONN);
        if ($iAmParent) {
            kill(-getpid(),SIGHUP);
            sleep(5);
            exit(1);
        }
        kill(0,SIGHUP);
        exit(1);
    }
    #$OSDB_ERROR_error=ERR_UNKNOWN;
    $testFailed = TRUE;  #/* Updated to be = TRUE.  JC */
}


sub countTuples {
    ($table) = ($_[0]);
    $cmd;
    $count;

    $cmd= "select count(col_key) from $table";
    $PGRESULT=$PGCONN->prepare($cmd);
    $PGRESULT->execute();
    ($count)=$PGRESULT->fetchrow_array;
    $PGRESULT->finish;
    return $count;
}


sub createIndexBtree() {
    ($iName, $tName, $fields)=($_[0],$_[1],$_[2]);
    $cmd="create index $iName on $tName using ($fields)";
    $PGRESULT=$PGCONN->do($cmd);
}

sub createIndexCluster() {
    my ($iName, $tName, $fields)=($_[0],$_[1],$_[2]);
    $cmd= "create unique index $iName on $tName using ($fields)";
    $PGRESULT=$PGCONN->do($cmd);
}

sub createIndexForeign {
    ($tName, $keyName, $keyCol,$fTable, $fFields)=($_[0],$_[1],$_[2],$_[3],$_[4]);
    $cmd="alter table $tName add constraint $keyName foreign key ($keyCol) references $ftable($fFields)";
    $PGRESULT=$PGCONN->do($cmd);
}


sub createIndexHash {
    my ($iName, $tName, $fields)=($_[0],$_[1],$_[2]);
    $cmd="create index $iName on $tName ($fields)";
    $PGRESULT=$PGCONN->do($cmd);
}


sub createTables { 
    my ($stg)=($_[0]);
    ddl($stg);
}

sub cursorClose() {
    #/* no-op under Postgres */
}

sub cursorDeclare {
    #/* no-op under Postgres */
}

sub cursorFetch {
    my ($dest)=($_[0]);
    $i;

    if ($PGRESULT!=NULL) {}
    $PGRESULT=$PGCONN->do("fetch MYCURSOR");
}

sub cursorOpen() {
    #/* no-op under Postgres */
}

sub databaseConnect {
    sprintf($DB_CONNECT_CMD, "dbname=%s", $DBNAME);
    $PGCONN=DBI->connect("dbi:Pg:dbname=$DBNAME", "postgres", "");
    $PGCONN->{PrintError}=1;
    $PGCONN->{RaiseError}=1;
    if ($PGCONN && $PGCONN->ping) {
        #BUGOUT($DB_CONNECT_CMD);
	}
}

sub databaseCreate {
    $PGCONN1=DBI->connect("dbi:Pg:dbname=template1", "postgres", "");
    $PGCONN1->{PrintError}=1;
    $PGCONN1->{RaiseError}=1;
    if ($PGCONN1 && $PGCONN1->ping) {
	$PGCONN1->do("drop database $DBNAME");
	$PGCONN1->do("create database $DBNAME");
    	$PGCONN1->disconnect;
        }
    else {
	exit(1);
	}
}

sub databaseDisconnect() {
    $PGCONN->disconnect;
}

sub sql_prep_exec {
    ($sql) = ($_[0]);
    $PGRESULT=$PGCONN->prepare($sql);
    $PGRESULT->execute();
}

sub ddl {
    my ($stg)=($_[0]);
    $PGRESULT=$PGCONN->do($stg);
    $the_err = $PGCONN->errstr;
    $OSDB_ERROR_error=$the_err; 
    if ($the_err) {
	printf "error $the_err \n";
	}
}

sub dml {
    my ($stg)=($_[0]);
    $PGRESULT=$PGCONN->do($stg);
    $the_err = $PGCONN->errstr;
    if ($the_err) {
	$PGCONN->rollback;
	}
    else {
	}
    $OSDB_ERROR_error=$the_err; 
    if ($the_err) {
	printf "error $the_err \n";
	}
}

sub interpretPGresult() {
    if ($PGRESULT==NULL) {
        TESTFAILED("interpretPGresult error");
	}
    #SWITCH: for (PQresultStatus($PGRESULT)) {
    #    /PGRES_COMMAND_OK/  && do {$OSDB_ERROR_error=ERR_OK;
    #                        last; };
    #    /PGRES_TUPLES_OK/   && do {if (PQntuples($PGRESULT)) {
    #                                $OSDB_ERROR_error=ERR_OK;
    #                            } else {
    #                                $OSDB_ERROR_error=ERR_NOTFOUND;
    #                            }
    #                            last; };
    #    /PGRES_BAD_RESPONSE/
    #    /PGRES_NONFATAL_ERROR/
    #    /PGRES_FATAL_ERROR/ && do {$OSDB_ERROR_error=ERR_UNKNOWN;
    #                            last; };
    #    {$OSDB_ERROR_error=ERR_UNKNOWN;
    #    TESTFAILED(PQresultErrorMessage($PGRESULT)); };
    #}
}


sub load {
    my $cmd;
    $cmd= "copy updates from '$dataDir/$FILENAME_UPDATES' with delimiter ','";
    dml($cmd);
    if ($OSDB_ERROR_error) {
        BUGOUT("cmd");
    }
    $cmd="copy hundred from '$dataDir/$FILENAME_HUNDRED' with delimiter ','";
    dml($cmd);
    if ($OSDB_ERROR_error) {
        BUGOUT("cmd");
    }
    $cmd="copy tenpct from '$dataDir/$FILENAME_TENPCT' with delimiter ','";
    dml($cmd);
    if ($OSDB_ERROR_error) {
        BUGOUT("cmd");
    }
    $cmd= "copy uniques from '$dataDir/$FILENAME_UNIQUES' with delimiter ','";
    dml($cmd);
    if ($OSDB_ERROR_error) {
        BUGOUT("cmd");
    }
    $cmd="copy tiny from '$dataDir/$FILENAME_TINY' with delimiter ','";
    dml($cmd);
    if ($OSDB_ERROR_error) {
        BUGOUT("cmd");
    }
    return 0;
}

sub setDefaults {
    ($DBNAME,$dataDir)=($_[0],$_[1]);
    $osdblog=stdout;
    $DBHOST=NULL;
    $DBUSER=NULL;
    $DBPORT=0;
}
sub create_idx_hundred_foreign() {
}

sub create_idx_hundred_code_h() {
        ddl('create index hundred_code_h on hundred (col_code)'); }

sub create_idx_hundred_key_bt() {
	ddl('create unique index hundred_key_bt on hundred (col_key)'); }

sub create_idx_tenpct_code_h() {
        ddl('create index tenpct_code_h on tenpct (col_code)'); }

sub create_idx_tenpct_decim_bt() {
        ddl('create index tenpct_decim_bt on tenpct (col_decim)') }

sub create_idx_tenpct_double_bt() {
        ddl('create index tenpct_double_bt on tenpct (col_double)'); }

sub create_idx_tenpct_float_bt() {
        ddl('create index tenpct_float_bt on tenpct(col_float)'); } sub create_idx_tenpct_int_bt() {
        ddl('create index tenpct_int_bt on tenpct(col_int)');
}

sub create_idx_tenpct_key_bt() {
        ddl('create unique index tenpct_key_bt on tenpct(col_key, col_code)'); }

sub create_idx_tenpct_key_code_bt() {
        ddl('create unique index tenpct_key_code_bt on tenpct(col_key, col_code)'); }

sub create_idx_tenpct_name_h() {
        ddl('create index tenpct_name_h on tenpct (col_name)'); }

sub create_idx_tenpct_signed_bt() {
         ddl('create index tenpct_signed_bt on tenpct (col_signed)'); }

sub create_idx_tiny_key_bt() {
        ddl('create unique index tiny_key_bt on tiny (col_key)'); } sub create_idx_uniques_code_h() {
	ddl('create index uniques_code_h on uniques (col_code)');
}

sub create_idx_uniques_key_bt() {
	ddl('create unique index uniques_key_bt on uniques(col_key)'); }

sub create_idx_updates_code_h() {
	ddl('create index updates_code_h on updates (col_code)');
}

sub create_idx_updates_decim_bt() {
        ddl('create index updates_decim_bt on updates(col_decim)'); }

sub create_idx_updates_double_bt() {
        ddl('create index updates_double_bt on updates(col_double)'); }

sub create_idx_updates_int_bt() {
        ddl('create index updates_int_bt on updates (col_int)'); }

sub create_idx_updates_key_bt() {
        ddl('create unique index updates_key_bt on updates (col_key)'); } sub sel_1_cl () { $count=0;
	sql_prep_exec('select col_key, col_int, col_signed, col_code, col_double, col_name from updates where col_key = 1000');
	while ((@cols)=$PGRESULT->fetchrow_array) {
		$count++;
	} 
        $PGRESULT->finish;
	return $count;
}
sub join_3_cl () {
$count=0;
	sql_prep_exec('select uniques.col_signed, uniques.col_date, hundred.col_signed, hundred.col_date, tenpct.col_signed, tenpct.col_date from uniques, hundred, tenpct where uniques.col_key = hundred.col_key and uniques.col_key = tenpct.col_key and uniques.col_key = 1000');
	while ((@cols)=$PGRESULT->fetchrow_array) {
                $count++;
        }
        $PGRESULT->finish;
        return $count;
}
sub sel_100_ncl () {
$count=0;
	sql_prep_exec('select col_key, col_int, col_signed, col_code, col_double, col_name from updates where col_int <= 100');
        while ((@cols)=$PGRESULT->fetchrow_array) {
                $count++;
        }
        $PGRESULT->finish;
        return $count;
}
sub sel_100_cl () {
$count=0;
	sql_prep_exec('select col_key, col_int, col_signed, col_code, col_double, col_name from updates where col_key <= 100');
	while ((@cols)=$PGRESULT->fetchrow_array) {
                $count++;
        }
        $PGRESULT->finish;
        return $count;
}
sub join_3_ncl() {
$count=0;
	sql_prep_exec("select uniques.col_signed, uniques.col_date, hundred.col_signed, hundred.col_date, tenpct.col_signed, tenpct.col_date from uniques, hundred, tenpct where uniques.col_code = hundred.col_code and uniques.col_code = tenpct.col_code and uniques.col_code = 'BENCHMARKS'");
	while ((@cols)=$PGRESULT->fetchrow_array) {
                $count++;
        }
        $PGRESULT->finish;
        return $count;
}
sub sel_10pct_ncl() {
$count=0;
	sql_prep_exec("select col_key, col_int, col_signed, col_code, col_double, col_name from tenpct where col_name = 'THE+ASAP+BENCHMARKS+'");
	while ((@cols)=$PGRESULT->fetchrow_array) {
                $count++;
        }
        $PGRESULT->finish;
        return $count;
}
sub simple_report () {
}
sub table_scan() {
    $count=0;
    sql_prep_exec('select * from uniques where col_int = 1');
    while ((@cols)=$PGRESULT->fetchrow_array) {
	$count++;
	}
    $PGRESULT->finish;
    return $count;
}
sub agg_func() {
    $col_key;
    $count=0;

    sql_prep_exec('select min(col_key) from   hundred group by col_name');
    while ((@cols)=$PGRESULT->fetchrow_array) {
	$count++;
	}
    $PGRESULT->finish;
    return $count;
}

sub agg_scal()
{
    $col_key[20];

    sql_prep_exec('select min(col_key) from uniques');
    ($col_key)=$PGRESULT->fetchrow_array;
    $PGRESULT->finish;
    return $col_key;
}

sub agg_simple_report()
{
    $avg;
    sql_prep_exec('select avg(updates.col_decim) from updates where updates.col_key in (select updates.col_key from updates, hundred where hundred.col_key = updates.col_key and updates.col_decim > 980000000)');
    ($avg)=$PGRESULT->fetchrow_array;
    $PGRESULT->finish;
    return $avg;
}

sub agg_info_retrieval() {
     $count;
     sql_prep_exec("select count(col_key) from tenpct where col_name = 'THE+ASAP+BENCHMARKS' and col_int <= 100000000 and col_signed between 1 and 99999999 and not (col_float between -450000000 and 450000000) and col_double > 600000000 and col_decim < -600000000");
    ($count)=$PGRESULT->fetchrow_array;
    $PGRESULT->finish;
    return $count;
}

sub agg_create_view() {
    ddl('create view reportview(col_key,col_signed,col_date,col_decim, col_name,col_code,col_int) as select updates.col_key, updates.col_signed, updates.col_date, updates.col_decim, hundred.col_name, hundred.col_code, hundred.col_int from updates, hundred where updates.col_key = hundred.col_key');
    $PGRESULT->finish;
    return 0;
}

sub agg_subtotal_report() {
	$count=0;
	sql_prep_exec('select avg(col_signed), min(col_signed), max(col_signed), max(col_date), min(col_date), count(distinct col_name), count(col_name), col_code, col_int from reportview where col_decim >980000000 group by col_code, col_int');

    while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    $PGRESULT->finish;
    return $count;
}
sub agg_total_report() {
	$count=0;
	sql_prep_exec('select avg(col_signed) , min(col_signed), max(col_signed), max(col_date), min(col_date), count(distinct col_name), count(col_name), count(col_code), count(col_int) from reportview where col_decim >980000000');
	while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
	return $count;
}
sub join_2_cl () {
	$count=0;
	sql_prep_exec('select uniques.col_signed, uniques.col_name, hundred.col_signed, hundred.col_name from uniques, hundred where uniques.col_key = hundred.col_key and uniques.col_key =1000');
	while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub join_2 () {
	$count=0;
	sql_prep_exec("select uniques.col_signed, uniques.col_name, hundred.col_signed, hundred.col_name from uniques, hundred where uniques.col_address = hundred.col_address and uniques.col_address = 'SILICON VALLEY'");
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub sel_variable_select_low() {
	$count=0;
	sql_prep_exec("select col_key, col_int, col_signed, col_code, col_double, col_name from tenpct where col_signed < -500000000");
	while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub sel_variable_select_high() {
	$count=0;
	sql_prep_exec('select col_key, col_int, col_signed, col_code, col_double, col_name from tenpct where col_signed < -250000000');
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub join_4_cl () {
	$count=0;
	sql_prep_exec('select uniques.col_date, hundred.col_date, tenpct.col_date, updates.col_date from uniques, hundred, tenpct, updates where uniques.col_key = hundred.col_key and uniques.col_key = tenpct.col_key and uniques.col_key = updates.col_key and uniques.col_key = 1000');
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub proj_100() {
	$count=0;
	sql_prep_exec('select distinct col_address, col_signed from hundred');
	while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub join_4_ncl () {
	$count=0;
	sql_prep_exec("select uniques.col_date, hundred.col_date, tenpct.col_date, updates.col_date from uniques, hundred, tenpct, updates where uniques.col_code = hundred.col_code and uniques.col_code = tenpct.col_code and uniques.col_code = updates.col_code and uniques.col_code = 'BENCHMARKS'");
	while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub proj_10pct () {
	$count=0;
	sql_prep_exec('select distinct col_signed from tenpct');
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub sel_1_ncl() {
	$count=0;
	sql_prep_exec("select col_key, col_int, col_signed, col_code, col_double, col_name from updates where col_code = 'BENCHMARKS'");
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub join_2_ncl() {
	$count=0;
	sql_prep_exec("select uniques.col_signed, uniques.col_name, hundred.col_signed, hundred.col_name from uniques, hundred where uniques.col_code = hundred.col_code and uniques.col_code = 'BENCHMARKS'");
        while ((@cols)=$PGRESULT->fetchrow_array) {
        $count++;
        }
    	$PGRESULT->finish;
        return $count;
}
sub integrity_test() {
    CREATE_TABLE_STANDARD('integrity_temp');
    ddl('insert into integrity_temp select * from hundred where col_int=0');
    ddl("update hundred set col_signed = '-500000000' where col_int = 0");
    ddl('delete from hundred where col_int = 0');
    ddl('insert into hundred select * from integrity_temp');
    ddl('drop table integrity_temp');
    return 0;
}
sub drop_updates_keys()
{
      ddl('drop index updates_int_bt');
      ddl('drop index updates_double_bt');
      ddl('drop index updates_decim_bt');
      ddl('drop index updates_code_h');
}
sub bulk_save() {
    CREATE_TABLE_STANDARD('saveupdates');
    dml('insert into saveupdates select * from updates where col_key between 5000 and 5999');
    return 0;
}

sub updates_int_bt (){
    dml('update updates set col_key = col_key - 100000 where col_key between 5000 and 5999'); }

sub bulk_modify() {
    dml('update updates set col_key = col_key - 100000 where col_key between 5000 and 5999'); }

sub upd_append_duplicate() {
}
sub upd_remove_duplicate() {
    dml("delete from updates where col_key = 6000 and col_int = 0"); }

sub mu_checkmod_100_rand() {}
sub mu_checkmod_100_seq() {}
sub mu_ir_select() {sleep(5);}
sub mu_mod_100_rand() {}
sub mu_mod_100_seq_abort() {}
sub mu_oltp_update() {}
sub mu_sel_100_rand() {}
sub mu_sel_100_seq() {}
sub mu_unmod_100_rand() {}
sub mu_unmod_100_seq() {}

1;

