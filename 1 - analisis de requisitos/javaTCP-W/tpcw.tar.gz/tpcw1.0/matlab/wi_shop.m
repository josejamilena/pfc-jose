function [n] = wi_shop()
%-------------------------------------------------------------------------
% function [n] = wi_shop()
%
% Returns the interaction number of the shop interaction.
%-------------------------------------------------------------------------

n =  15;

