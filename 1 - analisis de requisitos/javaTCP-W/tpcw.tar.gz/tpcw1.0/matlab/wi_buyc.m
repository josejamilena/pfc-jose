function [n] = wi_buyc()
%-------------------------------------------------------------------------
% function [n] = wi_buyc()
%
% Returns the interaction number of the buyc interaction.
%-------------------------------------------------------------------------

n =  5;

