function [n] = wi_buyr()
%-------------------------------------------------------------------------
% function [n] = wi_buyr()
%
% Returns the interaction number of the buyr interaction.
%-------------------------------------------------------------------------

n =  6;

