function [n] = wi_newp()
%-------------------------------------------------------------------------
% function [n] = wi_newp()
%
% Returns the interaction number of the newp interaction.
%-------------------------------------------------------------------------

n =  9;

