function [n] = wi_ordd()
%-------------------------------------------------------------------------
% function [n] = wi_ordd()
%
% Returns the interaction number of the ordd interaction.
%-------------------------------------------------------------------------

n =  10;

