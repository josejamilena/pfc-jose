function [n] = wi_sreq()
%-------------------------------------------------------------------------
% function [n] = wi_sreq()
%
% Returns the interaction number of the sreq interaction.
%-------------------------------------------------------------------------

n =  13;

