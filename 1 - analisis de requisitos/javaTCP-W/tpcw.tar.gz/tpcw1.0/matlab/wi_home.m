function [n] = wi_home()
%-------------------------------------------------------------------------
% function [n] = wi_home()
%
% Returns the interaction number of the home interaction.
%-------------------------------------------------------------------------

n =  8;

