function [n] = wi_sres()
%-------------------------------------------------------------------------
% function [n] = wi_sres()
%
% Returns the interaction number of the sres interaction.
%-------------------------------------------------------------------------

n =  14;

