function [n] = wi_creg()
%-------------------------------------------------------------------------
% function [n] = wi_creg()
%
% Returns the interaction number of the creg interaction.
%-------------------------------------------------------------------------

n =  7;

