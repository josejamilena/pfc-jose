function [n] = wi_ordi()
%-------------------------------------------------------------------------
% function [n] = wi_ordi()
%
% Returns the interaction number of the ordi interaction.
%-------------------------------------------------------------------------

n =  11;

