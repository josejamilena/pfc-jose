function [n] = wi_admc()
%-------------------------------------------------------------------------
% function [n] = wi_admc()
%
% Returns the interaction number of the admc interaction.
%-------------------------------------------------------------------------

n =  2;

