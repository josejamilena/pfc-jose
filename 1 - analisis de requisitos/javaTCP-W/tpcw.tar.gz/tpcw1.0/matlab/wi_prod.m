function [n] = wi_prod()
%-------------------------------------------------------------------------
% function [n] = wi_prod()
%
% Returns the interaction number of the prod interaction.
%-------------------------------------------------------------------------

n =  12;

