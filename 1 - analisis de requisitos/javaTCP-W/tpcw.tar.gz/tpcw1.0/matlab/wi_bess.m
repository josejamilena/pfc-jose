function [n] = wi_bess()
%-------------------------------------------------------------------------
% function [n] = wi_bess()
%
% Returns the interaction number of the bess interaction.
%-------------------------------------------------------------------------

n =  4;

