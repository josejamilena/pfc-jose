function [n] = wi_init()
%-------------------------------------------------------------------------
% function [n] = wi_init()
%
% Returns the interaction number of the init interaction.
%-------------------------------------------------------------------------

n = 1;

