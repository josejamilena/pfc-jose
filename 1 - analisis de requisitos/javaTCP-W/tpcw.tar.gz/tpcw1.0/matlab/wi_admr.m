function [n] = wi_admr()
%-------------------------------------------------------------------------
% function [n] = wi_admr()
%
% Returns the interaction number of the admr interaction.
%-------------------------------------------------------------------------

n =  3;

